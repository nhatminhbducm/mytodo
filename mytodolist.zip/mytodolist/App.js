/*import { Text, SafeAreaView, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Change code in the editor and watch it change on your phone! Save to get a shareable url.
      </Text>
      <Card>
        <AssetExample />
      </Card>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});*/


import React, { useState } from 'react';
import { View, Text, TextInput, Button, Switch } from 'react-native';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [taskName, setTaskName] = useState('');
  const [reminder, setReminder] = useState(false);
  const [searchText, setSearchText] = useState('');


  const addTask = () => {
    if (taskName.trim() !== '') {
      setTasks([...tasks, { name: taskName, reminder: reminder }]);
      setTaskName('');
      setReminder(false);
    }
  };

  const toggleReminder = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks[index].reminder = !updatedTasks[index].reminder;
    setTasks(updatedTasks);
  };

  const deleteTask = (index) => {
    const updatedTasks = [...tasks];
    updatedTasks.splice(index, 1);
    setTasks(updatedTasks);
  };

  const searchTasks = () => {
    const filteredTasks = tasks.filter((task) =>
      task.name.toLowerCase().includes(searchText.toLowerCase())
    );
    return filteredTasks;
  };

  return (
    <View style={{ padding: 16, alignItems: 'center', backgroundColor: '#87C4FF' }}>
      <Text style={{ fontSize: 24, fontWeight: 'bold', marginBottom: 20 }}>Todo App</Text>
      <TextInput style={{ marginBottom: 16, padding: 12, borderColor: '#000000', borderWidth: 1, width: 300, borderRadius: '22px', backgroundColor: '#ffffff'}}
        onChangeText={(text) => setTaskName(text)}
        value={taskName}
        placeholder=" "
      />
      <Button onPress={addTask} title="Add Item" paddingBottom='50'/>
      <Text style={{paddingTop: 15,}}>Search Item</Text>
      <TextInput style={{ marginBottom: 16, padding: 12, borderColor: '#000000', borderWidth: 1, width: 300, height: 25, color: 'black', borderRadius: '15px', backgroundColor: '#ffffff'}}
        onChangeText={(text) => setSearchText(text)}
        value={searchText}
        placeholder="Search..."
      />
      <View style={{ marginTop: 16 }}>
        {searchTasks().map((task, index) => (
          <View key={index} style={{ flexDirection: 'row', alignItems: 'center', paddingBottom: 20,}} >
            <Text style={{ flex: 1, paddingRight: 20, paddingLeft: 15, paddingTop: 5, color: '#ffffff', width: 210, borderBottom: 2, backgroundColor: '#39A7FF', borderBottomColor: '#1640D6', borderBottom: 'solid'}}>
              {task.name}
            </Text>
            <Switch value={task.reminder} onValueChange={() => toggleReminder(index)} />
            <Button onPress={() => deleteTask(index)} title="Delete" color="red" />
          </View>
        ))}
      </View>
    </View>
  );
}

